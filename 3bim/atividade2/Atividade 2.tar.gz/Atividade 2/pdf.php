<?php
	require('fpdf/fpdf.php');
	require_once 'init.php';
	$PDO = db_connect();
    $sql = "SELECT nomeCliente FROM clientes ORDER BY nomeCliente ASC";
	$stmt = $PDO->prepare($sql);
    $stmt->execute();
	
	$pdf = new Fpdf('P', 'pt', 'A4');
	$pdf->SetTitle('Teste pdf 1');
	$pdf->SetAuthor('Vitor Melo & Pedro de Deus');
	$pdf->SetCreator('php '.phpVersion());
	$pdf->SetKeywords('PHP', 'pdf');
	$pdf->SetSubject('Geração de Mala Direta');
	while($cliente = $stmt->fetch(PDO::FETCH_ASSOC)){
	//Conteúdo
	$pdf->AddPage();
	//Varginha e Data
	$pdf->Ln(20);
	$pdf->SetFont('Times','',14);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetY(20);
	$pdf->SetX(420);
	$titulo='Varginha, '.date("d/m/Y");
	$titulo=utf8_decode($titulo);
	$pdf->Write(30, $titulo);
	//Prezado
	$pdf->Ln(55);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$welcome="Prezado(a) Sr(a) ".$cliente['nomeCliente'].",";
	$pdf->Write(25,$welcome);
	//Conteúdo
	$pdf->Ln(90);
	$pdf->SetX(80);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$conteudo="Neste mês de aniversário, nossa loja está com promoções impredíveis e selecionados especialmente para você.";
	$conteudo=utf8_decode($conteudo);
	$pdf->Write(17,$conteudo);
	//Conteúdo 2
	$pdf->Ln(15);
	$pdf->SetX(80);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$conteudo="Não perca esta oportunidade de realizar bons negócios.";
	$conteudo=utf8_decode($conteudo);
	$pdf->Write(25,$conteudo);
	//Conteúdo 3
	$pdf->Ln(17);
	$pdf->SetX(80);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$conteudo="Faça-nos uma visita.";
	$conteudo=utf8_decode($conteudo);
	$pdf->Write(25,$conteudo);
	//Cordialmente
	$pdf->Ln(100);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$cord="Cordialmente,";
	$pdf->Write(25,$cord);
	//Gerência
	
	
	$pdf->Ln(100);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','B',14);
	$cord="Pedro Barbosa";
	$pdf->Cell(510, 20, $cord, 0, 1, 'C');
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$ger="Gerente Comerical";
	$pdf->Cell(510, 20, $ger, 0, 1, 'C');
	
	
	
	}$pdf->Output();
	
	
?>
