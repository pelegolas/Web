<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Pokémon GO</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

	<link rel="stylesheet" href="http://localhost/pokemon/assets/login.css">
</head>
<body>
	
	<div class="container">

      <div class="col-lg-4 col-lg-offset-4 my_form">
      	<img src="http://localhost/pokemon/assets/images/pokemongo.png" class="main">

      	<h2 class="text-center">Seja Bem Vindo!</h2>
      	<div class ="form-login">

		<?php echo validation_errors();
			echo form_open(base_url('login/logar'),array('id'=>'login')) .
			form_input(array('id'=>'login', 'name'=>'login','Placeholder'=>'Login','value'=>set_value('login'))) .
			form_password(array('id'=>'senha','name'=>'senha','Placeholder'=>'Senha')) .
			form_submit("btnLogin","Entrar") .
			form_close(); ?>
    	</div> 
      </div>
    </div>
</body>
</html>