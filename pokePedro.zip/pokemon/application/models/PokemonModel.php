<?php
defined('BASEPATH') OR exit('No direct script access allowed');
  class PokemonModel extends CI_Model {
    public function __construct(){
      parent::__construct();
    }
    public function exibirPokemon(){
      return $this->db->get('pokemon')->result();
    }
    
    public function deletarPokemon($id){
    	$this->db->where('id_pokemon', $id);
   	$this->db->delete('pokemon');
    }
}
?>