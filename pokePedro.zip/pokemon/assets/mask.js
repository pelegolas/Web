$(document).ready(function(){
		$('#data').mask('0000/00/00 00:00', {reverse: true});
});